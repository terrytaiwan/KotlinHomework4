package com.example.lab12

import android.app.Service
import android.content.Intent
import android.os.IBinder
import kotlinx.coroutines.*

class MyService : Service() {

    // 1. 定義協程作用域
    private val serviceScope = CoroutineScope(Dispatchers.Main)

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // 2. 啟動協程
        serviceScope.launch {
            delay(3000) // 延遲 3 秒

            // 啟動 Activity
            // 這裡修正了錯誤：使用 addFlags 來避免變數名稱衝突
            val targetIntent = Intent(this@MyService, SecActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(targetIntent)

            // 任務完成後停止 Service
            stopSelf()
        }

        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        // 取消所有協程，避免記憶體洩漏
        serviceScope.cancel()
    }
}