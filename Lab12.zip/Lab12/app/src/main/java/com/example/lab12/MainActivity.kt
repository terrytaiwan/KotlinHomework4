package com.example.lab12

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
// 記得引入你專案自動生成的 Binding 類別，通常是 Activity名稱 + Binding
import com.example.lab12.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    // 1. 宣告 Binding 變數
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // 2. 初始化 Binding
        binding = ActivityMainBinding.inflate(layoutInflater)
        // 3. 使用 binding.root 取代原本的 R.layout.activity_main
        setContentView(binding.root)

        // 處理視窗邊緣 (Edge-to-Edge) 的邏輯，這裡改用 binding.main (假設你的根佈局 ID 是 main)
        ViewCompat.setOnApplyWindowInsetsListener(binding.main) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // 4. 優化按鈕監聽器：不再需要 findViewById，直接用 ID 名字 (btnStart)
        binding.btnStart.setOnClickListener {
            // 啟動 Service
            startService(Intent(this, MyService::class.java))

            // 顯示 Toast
            Toast.makeText(this, "啟動Service", Toast.LENGTH_SHORT).show()

            // 關閉 Activity
            finish()
        }
    }
}