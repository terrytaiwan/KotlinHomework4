package com.example.lab12

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
// 記得引入自動產生的 Binding 類別
import com.example.lab12.databinding.ActivitySecBinding

class SecActivity : AppCompatActivity() {

    // 1. 宣告 Binding 變數
    private lateinit var binding: ActivitySecBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // 2. 初始化 View Binding
        binding = ActivitySecBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // 3. 設定邊緣顯示 (處理瀏海頭或虛擬按鍵遮擋問題)
        // 使用 binding.main 直接取得根佈局 (前提是你的 activity_sec.xml 根佈局 ID 設為 main)
        // 如果你的 xml 根佈局 ID 不是 main，請改成 binding.root
        ViewCompat.setOnApplyWindowInsetsListener(binding.main) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}